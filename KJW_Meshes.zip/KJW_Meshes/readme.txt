Here are 2 models King01_UFO and Queen01_UFO I made I am giving the to epic games to use if epic wants them some of the mats are from packs that I have purchased on Unreals market place like Mothership service rooms, and scifi chambers enviroment and one from the projectiles and pack 2 robot mats from modular characters blueprint and a link gun mat and to that I edited a glowing transparnt mat and a glass mat2.

Kenneth J. Williams
kjwtechno@charter.net
 